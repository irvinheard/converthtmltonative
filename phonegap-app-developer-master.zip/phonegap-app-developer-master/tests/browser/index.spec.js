
describe('PhoneGap Developer App', function() {

    it('runs and you are not insane', function() {
        expect(true).toBe(true);
    });

    it('runs and you are not insane', function() {
        expect(false).toBe(false);
    });


});
